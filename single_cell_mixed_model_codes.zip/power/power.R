rm(list=ls())

setwd('D:\\GoogleDrive\\projects\\single_cell\\results\\power')

png('power_curve_single_cell.png', width = 15, height=6, units='in', res=300)
m = matrix(c(1,2,3),nrow = 1,ncol = 3,byrow = TRUE)
layout(mat = m,heights = 1)

par(oma=c(0,0.2,0,0))
#gaussian
beta_g = c(0, 0.25, 0.5, 0.75, 1, 1.25, 1.5)
GR_c_g = c(0.068, 0.212, 0.671, 0.964, 1, 1, 1)
GR_s_g = c(0.058, 0.207, 0.614, 0.932, 0.999, 1, 1)
GR_b_g = c(0.049, 0.192, 0.583, 0.912, 0.996, 1, 1)
mast_g = c(0.067, 0.137, 0.397, 0.721, 0.907, 0.999, 1)
g_nr_g = c(0.057, 0.121, 0.341, 0.642, 0.872, 0.996, 1)

plot(beta_g, GR_s_g, type='l', lwd=3, xlim=c(0,1.5), ylim=c(0,1), axes=F, frame.plot=T, 
     ylab='Power (% of p<0.05)', xlab='Effect size (log fold change)', cex.lab=1.5, font.lab=2, main='Gaussian', cex.main=2)
lines(beta_g, GR_c_g, lwd=3, col='purple')
lines(beta_g, GR_b_g, lwd=3, col='red')
lines(beta_g, mast_g, lwd=3, col='blue')
lines(beta_g, g_nr_g, lwd=3, col='green')
abline(h=0.05, lty=2, lwd=3, col='red')

axis(side=1, at=seq(0, 1.5, 0.25), labels=seq(0, 1.5, 0.25), cex.axis=1.3, font=2)
axis(side=2, at=seq(0,1,by=0.1), labels=c('0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'), cex.axis=1.3, font=2)
mtext('A', at=-0.1, line=1, font=2, cex=2)

#binomial
beta_b = c(0, 0.25, 0.5, 0.75, 1, 1.25, 1.5)
GR_c_b = c(0.065, 0.191, 0.584, 0.901, 0.992, 1, 1)
GR_s_b = c(0.057, 0.176, 0.521, 0.842, 0.928, 0.981, 1)
GR_b_b = c(0.048, 0.158, 0.476, 0.765, 0.902, 0.963, 1)
mast_b = c(0.069, 0.123, 0.321, 0.621, 0.831, 0.942, 0.999)
g_nr_b = c(0.058, 0.101, 0.301, 0.584, 0.782, 0.921, 0.996)

plot(beta_b, GR_s_b, type='l', lwd=3, xlim=c(0,1.5), ylim=c(0,1), axes=F, frame.plot=T, 
     ylab='Power (% of p<0.05)', xlab='Effect size (log odds ratio of zero propotion)', cex.lab=1.5, font.lab=2, main='Binomial', cex.main=2)
lines(beta_b, GR_c_b, lwd=3, col='purple')
lines(beta_b, GR_b_b, lwd=3, col='red')
lines(beta_b, mast_b, lwd=3, col='blue')
lines(beta_b, g_nr_b, lwd=3, col='green')
abline(h=0.05, lty=2, lwd=3, col='red')

axis(side=1, at=seq(0, 1.5, 0.25), labels=seq(0, 1.5, 0.25), cex.axis=1.3, font=2)
axis(side=2, at=seq(0,1,by=0.1), labels=c('0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'), cex.axis=1.3, font=2)
mtext('B', at=-0.1, line=1, font=2, cex=2)

#combine
beta_c = c(0, 0.25, 0.5, 0.75, 1, 1.25, 1.5)
GR_c_c = c(0.069, 0.259, 0.732, 0.981, 1, 1, 1)
GR_s_c = c(0.062, 0.257, 0.692, 0.967, 0.999, 1, 1)
GR_b_c = c(0.057, 0.214, 0.664, 0.958, 0.999, 1, 1)
mast_c = c(0.071, 0.189, 0.462, 0.812, 0.987, 0.999, 1)
g_nr_c = c(0.064, 0.158, 0.415, 0.753, 0.961, 0.996, 1)

plot(beta_c, GR_s_c, type='l', lwd=3, xlim=c(0,1.5), ylim=c(0,1), axes=F, frame.plot=T, 
     ylab='Power (% of p<0.05)', xlab='Effect size (combinations of Gaussian and binomial)', cex.lab=1.5, font.lab=2, main='Combine', cex.main=2)
lines(beta_c, GR_c_c, lwd=3, col='purple')
lines(beta_c, GR_b_c, lwd=3, col='red')
lines(beta_c, mast_c, lwd=3, col='blue')
lines(beta_c, g_nr_c, lwd=3, col='green')
abline(h=0.05, lty=2, lwd=3, col='red')

legend(x=0.75, y=0.4, legend = c('TMM - Chi-square', 'TMM - Satterthwaite', 'TMM - bootstrap','MAST', 'TM'),
       col=c('purple','black','red','blue','green'), lwd=rep(3,5), lty=rep(1,5), cex=1.4)

axis(side=1, at=seq(0, 1.5, 0.25), labels=seq(0, 1.5, 0.25), cex.axis=1.3, font=2)
axis(side=2, at=seq(0,1,by=0.1), labels=c('0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'), cex.axis=1.3, font=2)
mtext('C', at=-0.1, line=1, font=2, cex=2)
dev.off()