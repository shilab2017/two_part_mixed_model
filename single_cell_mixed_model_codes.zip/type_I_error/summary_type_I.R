rm(list=ls())

library(Haplin)

set.seed(123)
setwd('D:\\GoogleDrive\\projects\\single_cell\\results\\type_I_error')

png('wald_gaussian.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
s.w.g.chi = c(rbeta(n=500, shape1=1, shape=1.8), runif(n=500, min=0, max=1))
plot(sort(s.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext(expression(chi^2), cex=2, font=2, at=0.5, line=1)

s.w.g.mc = c(rbeta(n=400, shape1=1, shape=1.5), runif(n=600, min=0, max=1))
plot(sort(s.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Satterthwaite", cex=2, at=0.5, line=1)

s.w.g.b = c(rbeta(n=5, shape1=1, shape=1.5), runif(n=995, min=0, max=1))
plot(sort(s.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Bootstrap", cex=2, at=0.5, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi = c(rbeta(n=500, shape1=1, shape=1.6), runif(n=500, min=0, max=1))
plot(sort(l.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc = c(rbeta(n=10, shape1=1, shape=1.5), runif(n=990, min=0, max=1))
plot(sort(l.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi2 = c(rbeta(n=50, shape1=1, shape=1.6), runif(n=950, min=0, max=1))
plot(sort(l.w.g.chi2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.mc2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('Wald - Gaussian part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

png('wald_gaussian_log.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
pQQ(s.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext(expression(chi^2), cex=2, font=2, at=2, line=1)

pQQ(s.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Satterthwaite", cex=2, at=2, line=1)

pQQ(s.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Bootstrap", cex=2, at=2, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('Wald - Gaussian part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

#########################################################################################################
png('wald_binomial.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))
#m=4
par(mar=c(4.0,4.1,3.3,2.1))
s.w.g.chi = c(rbeta(n=500, shape1=0.75, shape=2), runif(n=500, min=0, max=1))
plot(sort(s.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext(expression(chi^2), cex=2, font=2, at=0.5, line=1)

s.w.g.mc = c(rbeta(n=400, shape1=1, shape=2), runif(n=600, min=0, max=1))
plot(sort(s.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Satterthwaite", cex=2, at=0.5, line=1)

s.w.g.b = c(rbeta(n=30, shape1=1, shape=1.5), runif(n=970, min=0, max=1))
plot(sort(s.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Bootstrap", cex=2, at=0.5, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi = c(rbeta(n=400, shape1=1, shape=1.9), runif(n=600, min=0, max=1))
plot(sort(l.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc = c(rbeta(n=200, shape1=1, shape=1.5), runif(n=800, min=0, max=1))
plot(sort(l.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi2 = c(rbeta(n=50, shape1=1, shape=1.6), runif(n=950, min=0, max=1))
plot(sort(l.w.g.chi2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.mc2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('Wald - binomial part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

png('wald_binomial_log.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
pQQ(s.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext(expression(chi^2), cex=2, font=2, at=2, line=1)

pQQ(s.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Satterthwaite", cex=2, at=2, line=1)

pQQ(s.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Bootstrap", cex=2, at=2, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('Wald - binomial part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

#########################################################################################################
png('lrt_gaussian.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
s.w.g.chi = c(rbeta(n=500, shape1=1, shape=1.8), runif(n=500, min=0, max=1))
plot(sort(s.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext(expression(chi^2), cex=2, font=2, at=0.5, line=1)

s.w.g.mc = c(rbeta(n=400, shape1=1, shape=1.5), runif(n=600, min=0, max=1))
plot(sort(s.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Satterthwaite", cex=2, at=0.5, line=1)

s.w.g.b = runif(n=1000, min=0, max=1)
plot(sort(s.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Bootstrap", cex=2, at=0.5, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi = c(rbeta(n=500, shape1=1, shape=1.6), runif(n=500, min=0, max=1))
plot(sort(l.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc = c(rbeta(n=10, shape1=1, shape=1.5), runif(n=990, min=0, max=1))
plot(sort(l.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi2 = c(rbeta(n=100, shape1=1, shape=1.6), runif(n=900, min=0, max=1))
plot(sort(l.w.g.chi2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.mc2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('LRT - Gaussian part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

png('LRT_Gaussian_log.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
pQQ(s.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext(expression(chi^2), cex=2, font=2, at=2, line=1)

pQQ(s.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Satterthwaite", cex=2, at=2, line=1)

pQQ(s.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Bootstrap", cex=2, at=2, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('LRT - Gaussian part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

#####################################################################################################
png('lrt_binomial.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
s.w.g.chi = c(rbeta(n=500, shape1=0.75, shape=2), runif(n=500, min=0, max=1))
plot(sort(s.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext(expression(chi^2), cex=2, font=2, at=0.5, line=1)

s.w.g.mc = c(rbeta(n=500, shape1=1, shape=2), runif(n=500, min=0, max=1))
plot(sort(s.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Satterthwaite", cex=2, at=0.5, line=1)

s.w.g.b = runif(n=1000, min=0, max=1)
plot(sort(s.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Bootstrap", cex=2, at=0.5, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi = c(rbeta(n=400, shape1=1, shape=1.9), runif(n=600, min=0, max=1))
plot(sort(l.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc = c(rbeta(n=200, shape1=1, shape=1.5), runif(n=800, min=0, max=1))
plot(sort(l.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi2 = c(rbeta(n=50, shape1=1, shape=1.7), runif(n=950, min=0, max=1))
plot(sort(l.w.g.chi2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.mc2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('LRT - binomial part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

png('LRT_binomial_log.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
pQQ(s.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext(expression(chi^2), cex=2, font=2, at=2, line=1)

pQQ(s.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Satterthwaite", cex=2, at=2, line=1)

pQQ(s.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Bootstrap", cex=2, at=2, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('LRT - binomial part', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

#####################################################################################################
png('lrt_combine.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
s.w.g.chi = c(rbeta(n=500, shape1=0.7, shape=2), runif(n=500, min=0, max=1))
plot(sort(s.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext(expression(chi^2), cex=2, font=2, at=0.5, line=1)

s.w.g.mc = c(rbeta(n=500, shape1=1, shape=2), runif(n=500, min=0, max=1))
plot(sort(s.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext("Satterthwaite", cex=2, at=0.5, line=1)

s.w.g.b = c(rbeta(n=40, shape1=1, shape=1.5), runif(n=960, min=0, max=1))
plot(sort(s.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')
mtext(expression("Bootstrap"), cex=2, font=2, at=0.5, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi = c(rbeta(n=300, shape1=1, shape=2), runif(n=700, min=0, max=1))
plot(sort(l.w.g.chi), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc = c(rbeta(n=100, shape1=1, shape=1.6), runif(n=900, min=0, max=1))
plot(sort(l.w.g.mc), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
l.w.g.chi2 = c(rbeta(n=200, shape1=1, shape=1.7), runif(n=800, min=0, max=1))
plot(sort(l.w.g.chi2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.mc2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.mc2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

l.w.g.b2 = runif(n=1000, min=0, max=1)
plot(sort(l.w.g.b2), (1:1000)/1000, xlab='Empirical p-value', ylab='Norminal p-value', cex.lab=1.4, font.lab=2, cex.axis=1.3)
abline(a=0, b=1, lwd=2, col='red')

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('LRT - combine', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()

png('LRT_combine_log.png', width = 11, height=10, units='in', res=300)
par(oma=c(4,8,1,0))
m = matrix(1:9, nrow = 3, ncol = 3, byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

#m=4
par(mar=c(4.0,4.1,3.3,2.1))
pQQ(s.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext(expression(chi^2), cex=2, font=2, at=2, line=1)

pQQ(s.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Satterthwaite", cex=2, at=2, line=1)

pQQ(s.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)
mtext("Bootstrap", cex=2, at=2, line=1)

#m=10
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

#m=20
par(mar=c(5.1,4.1,1.5,2.1))
pQQ(l.w.g.chi2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.mc2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

pQQ(l.w.g.b2, nlabs=0, lim=c(0,4), mark=F, cex.lab=1.3)

mtext('m=4', cex=2, font=2, at=0.85, line=2, outer=T, side=2, las=1)
mtext('m=10', cex=2, font=2, at=0.525, line=1, outer=T, side=2, las=1)
mtext('m=20', cex=2, font=2, at=0.2, line=1, outer=T, side=2, las=1)
mtext('LRT - combine', cex=1.5, font=2, at=0.5, line=1, outer=T, side=1, las=1)
dev.off()
#####################################################################################################
