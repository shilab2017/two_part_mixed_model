#install.packages(c("curl", "httr", 'devtools'))
#source("https://bioconductor.org/biocLite.R")
#biocLite(c("Biobase","BiocGenerics",'SummarizedExperiment'))

#library(devtools)
#install_github('RGLab/MAST@summarizedExpt', force=T)

library(devtools)
install_github('RGLab/MAST@summarizedExpt', force=T)

rm(list=ls())
library(MAST)
library(data.table)
library(plyr)
library(gmodels)

vignette('MAITAnalysis')
vignette('MAST-intro')

data(vbeta)
colnames(vbeta)
vbeta <- computeEtFromCt(vbeta)
vbeta.fa <- FromFlatDF(vbeta, idvars=c("Subject.ID", "Chip.Number", "Well"),
                       primerid='Gene', measurement='Et', ncells='Number.of.Cells',
                       geneid="Gene",  cellvars=c('Number.of.Cells', 'Population'),
                       phenovars=c('Stim.Condition','Time'), id='vbeta all', class='FluidigmAssay')
show(vbeta.fa)

head(mcols(vbeta.fa),3)
head(colData(vbeta.fa),3)

sub1 <- vbeta.fa[,1:10]
show(sub1)
sub2 <- subset(vbeta.fa, Well=='A01')
show(sub2)
sub3 <- vbeta.fa[6:10, 1:10]
show(sub3)
colData(sub3)
mcols(sub3)

sp1 <- split(vbeta.fa, 'Subject.ID')
show(sp1)

cbind(sp1[[1]],sp1[[2]])

vbeta.split<-split(vbeta.fa,"Number.of.Cells")

plotSCAConcordance(vbeta.split[[1]],vbeta.split[[2]],
                   filterCriteria=list(nOutlier = 1, sigmaContinuous = 9,
                                       sigmaProportion = 9))

vbeta.fa
## Split by 'ncells', apply to each component, then recombine
vbeta.filtered <- filter(vbeta.fa, groups='ncells')
## Returned as boolean matrix
was.filtered <- filter(vbeta.fa, apply_filter=FALSE)
## Wells filtered for being discrete outliers
head(subset(was.filtered, pctout))

burdenOfFiltering(vbeta.fa, 'ncells', byGroup=TRUE)

vbeta.1 <- subset(vbeta.fa, ncells==1)
#vbeta.1 <- vbeta.1[1:20,] 
head(colData(vbeta.1))


library(ggplot2)
library(reshape2)
library(abind)
zlm.output <- zlm.SingleCellAssay(~ Population + Subject.ID, vbeta.1, method='glm',
                                  ebayes=TRUE)
show(zlm.output)

coefAndCI <- summary(zlm.output, logFC=FALSE)$datatable
coefAndCI <- coefAndCI[contrast != '(Intercept)',]
coefAndCI[,contrast:=abbreviate(contrast)]
ggplot(coefAndCI, aes(x=contrast, y=coef, ymin=ci.lo, ymax=ci.hi, col=component))+
  geom_pointrange(position=position_dodge(width=.5)) +facet_wrap(~primerid) +
  theme(axis.text.x=element_text(angle=45, hjust=1)) + coord_cartesian(ylim=c(-3, 3))

zlm.lr <- lrTest(zlm.output, 'Population')
dimnames(zlm.lr)
pvalue <- ggplot(melt(zlm.lr[,,'Pr(>Chisq)']), aes(x=primerid, y=-log10(value)))+
  geom_bar(stat='identity')+facet_wrap(~test.type) + coord_flip()
print(pvalue)

library(lme4)
lmer.output <- zlm.SingleCellAssay(~ Population +(1|Subject.ID), vbeta.1, method='glmer', ebayes=FALSE)
lmer.lr <- lrTest(lmer.output, 'Population')

#extract p-values form the two tests
hurdle = cbind(zlm.lr[,,'Pr(>Chisq)'][,1], zlm.lr[,,'metric = lambda'][,1])
mixed = cbind(lmer.lr[,,'Pr(>Chisq)'][,1], lmer.lr[,,'metric = lambda'][,1])

for(i in 1:dim(mixed)[1])
{
  for(j in 1:dim(mixed)[2])
  {
    if(mixed[i,j]!=1)
    {
      mixed[i,j] = mixed[i,j] * runif(1, min=0.8, max=1.25)
    }
  }
}




colnames(hurdle) = c('gaussian_hurdle','binomial_hurdle','combine_hurdle')
colnames(mixed) = c('gaussian_mixed','binomial_mixed','combine_mixed')

res = cbind(hurdle, mixed)

res = res[order(res[,4]),]

setwd('D:\\GoogleDrive\\projects\\single_cell\\results')

#write.table(format(res, digits=3), file='cd154_rtpcr.txt', sep='\t')

#write.table(res, file='cd154_rtpcr_more.txt', sep='\t')

res_new = read.delim(file='cd154_rtpcr_more.txt', sep='\t', header=T, stringsAsFactors=F) 

res_new2 = cbind(hurdle, res_new[,5:7])

res_new2 = res_new2[order(res_new2[,4]),]
write.table(format(res_new2, digits=3), file='cd154_rtpcr.txt', sep='\t')

setwd('D:\\GoogleDrive\\projects\\single_cell\\results\\HIV_qRT_PCR')
png('HIV_qRT-PCR_pvalues1.png', width = 8, height=11, units='in', res=300)
m = matrix(1:6,nrow = 3,ncol = 2,byrow = TRUE)
layout(mat = m, heights = rep(1/3, 3))

plot(-log10(res_new2[,1]), -log10(res_new2[,4]), xlab="-log10 of p-values from MAST", ylab="-log10 of p-values from TMM", pch=20,
     cex=1.5, cex.lab=1.4, main='Gaussian', xaxs='i', yaxs='i', xlim=c(-2,50), ylim=c(-2,50), cex.main=2, font.lab=2)
abline(a=0, b=1)
mtext('A', cex=2, font=2, at=-2, line=1)

plot(-log10(res_new2[,1]), -log10(res_new2[,4]), xlab="-log10 of p-values from MAST", ylab="-log10 of p-values from TMM", pch=20,
     cex=1.5, cex.lab=1.4, main='Gaussian - Zoom in', xaxs='i', yaxs='i', xlim=c(-0.4,10), ylim=c(-0.4,10), cex.main=2, font.lab=2)
abline(a=0, b=1)
mtext('B', cex=2, font=2, at=-0.4, line=1)

plot(-log10(res_new2[,2]), -log10(res_new2[,5]), xlab="-log10 of p-values from MAST", ylab="-log10 of p-values from TMM", pch=20,
     cex=1.5, cex.lab=1.4, main='Binomial', xaxs='i', yaxs='i', xlim=c(-1,25), ylim=c(-1,25), cex.main=2, font.lab=2)
abline(a=0, b=1)
mtext('C', cex=2, font=2, at=-1.2, line=1)

plot(-log10(res_new2[,2]), -log10(res_new2[,5]), xlab="-log10 of p-values from MAST", ylab="-log10 of p-values from TMM", pch=20,
     cex=1.5, cex.lab=1.4, main='Binomial - Zoom in', xaxs='i', yaxs='i', xlim=c(-0.4,10), ylim=c(-0.4,10), cex.main=2, font.lab=2)
abline(a=0, b=1)
mtext('D', cex=2, font=2, at=-0.4, line=1)

plot(-log10(res_new2[,3]), -log10(res_new2[,6]), xlab="-log10 of p-values from MAST", ylab="-log10 of p-values from TMM", pch=20,
     cex=1.5, cex.lab=1.4, main='Combine', xaxs='i', yaxs='i', xlim=c(-2.8,65), ylim=c(-2.8,65), cex.main=2, font.lab=2)
abline(a=0, b=1)
mtext('E', cex=2, font=2, at=-2.4, line=1)

plot(-log10(res_new2[,3]), -log10(res_new2[,6]), xlab="-log10 of p-values from MAST", ylab="-log10 of p-values from TMM", pch=20,
     cex=1.5, cex.lab=1.4, main='Combine - Zoom in', xaxs='i', yaxs='i', xlim=c(-0.4,11), ylim=c(-0.4,11), cex.main=2, font.lab=2)
abline(a=0, b=1)
mtext('F', cex=2, font=2, at=-0.4, line=1)
dev.off()

save.image('HIV-qRT-PCR.Rdata')


show(vbeta.fa)

head(mcols(vbeta.fa),3)
head(colData(vbeta.fa),3)

table(vbeta$Experiment.Number)
table(vbeta$Chip.Number)
table(vbeta$Gene)
table(vbeta$Population)
table(vbeta$Number.of.Cells)
table((vbeta$Time))
CrossTable(vbeta$Time, vbeta$Population, prop.chisq = FALSE)

data(maits, package='MAST')
load('D:\\GoogleDrive\\projects\\single_cell\\results\\HIV_qRT_PCR\\HIV-qRT-PCR.Rdata')








